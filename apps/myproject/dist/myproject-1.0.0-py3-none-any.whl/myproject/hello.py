def handler():
	return {
		"statusCode": 200,
		"body": "Hello world"
	}