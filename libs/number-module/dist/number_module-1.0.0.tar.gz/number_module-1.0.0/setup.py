# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['number_module']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'number-module',
    'version': '1.0.0',
    'description': '',
    'long_description': '# number-module\n\n## About\n\nProject description here.\n\n[API Documentation](docs/source/api.md)\n\n## [Change log](CHANGELOG.md)\n',
    'author': 'None',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
