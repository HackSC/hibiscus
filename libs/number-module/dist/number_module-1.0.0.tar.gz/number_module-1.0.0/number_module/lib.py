def is_odd(num):
    return num%2!=0